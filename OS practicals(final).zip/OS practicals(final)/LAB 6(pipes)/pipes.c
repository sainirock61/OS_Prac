#include<stdio.h>
#include<sys/types.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/wait.h>

int main(){
     char messageWrite[50] = " HELLO WORLD! "  ;
     char messageRead[50];
     int fd[2]; //fd[0]  read end ;fd[1]  write end
     if(pipe(fd) == -1){
          fprintf(stderr,"\nError creating pipe");
     }

     pid_t mpid;
     mpid = fork();
     if(mpid < 0 ){
          fprintf(stderr,"\nFailed to fork child\n");
          exit(1);
     }
     else if(mpid == 0){
          close(fd[1]);
          read(fd[0],messageRead,50);
          printf("%s",messageRead);
          close(fd[0]);
     }
     else{
          close(fd[0]);
          write(fd[1],messageWrite,strlen(messageWrite));
          close(fd[1]);
          wait(NULL);
          printf("\nParent process ended after child process ends");
     }
     return 0;
}
