#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>

//child and parent executing same program but different code
int main(){
     pid_t mpid = fork();
     if(mpid<0){
          fprintf(stderr,"\nFailed to fork child.");
          return 1;
     }
     else if(mpid == 0){
          printf("\nInside Child Process");
     }
     else{
          printf("\nInside Parent Process");
     }
     return 0;
}
