#include<stdio.h>
#include<stdlib.h>
int main(){
	printf("\n***  Program to write to a file  ***\n");
	char path[1000];
	printf("\nEnter the path or file name:");
	scanf("%s",path);
	printf("\n%s",path);
	char text[1000];
	printf("\nEnter the text you want to write to the file:");
	scanf("%[\n]",text); // Dump the extra new line character from the previous input
	scanf("%[^\n]",text); // Take the input until the new line character
	FILE *fptr;
	fptr=fopen(path,"w");
	if(fptr==NULL){
		printf("\nError opening file!!");
		exit(1);
	}

	fprintf(fptr,"%s",text);
	printf("Text has been written on to the file.");
	fclose(fptr);

	return 0;
}
