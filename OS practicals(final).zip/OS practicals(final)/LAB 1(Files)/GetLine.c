#include<stdio.h>
#include<stdlib.h>

void getLine(FILE *fptr,char* str){
	int c;
	int delim='\n';
	int i=0;
	do{
		c=fgetc(fptr);
		if(c==(int)delim || c==EOF)
			break;
		str[i++]=(char)c;

	}while(1);
	str[i]='\0';
}

int main(){
	char text[1000];
	printf("%s","\nEnter the text:");
	getLine(stdin,text);
	printf("\nYou Entered:%s",text);
	return 0;
}
