#include<sys/types.h>
#include<stdio.h>
#include<sys/stat.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
#include<string.h>
#include<errno.h>
#include<time.h>

void strperm(mode_t m,char * buf ){
     buf[0] = (m & S_IFREG)? '-':'d';
     buf[1] = (m & S_IRUSR)? 'r':'-';
     buf[2] = (m & S_IWUSR)? 'w':'-';
     buf[3] = (m & S_IXUSR)? 'x':'-';
     buf[4] = (m & S_IRGRP)? 'r':'-';
     buf[5] = (m & S_IWGRP)? 'w':'-';
     buf[6] = (m & S_IXGRP)? 'x':'-';
     buf[7] = (m & S_IROTH)? 'r':'-';
     buf[8] = (m & S_IWOTH)? 'w':'-';
     buf[9] = (m & S_IXOTH)? 'x':'-';
     buf[10] = '\0';
}


int main(int argc,char * argv[]){
     char * filename;
     int file_desc;
     struct stat info;
     char buf[11];


     if(argc<2){
          printf("\nArguments required!");
          exit(1);
     }
     filename=argv[1];
     file_desc=open(filename,O_RDONLY); //stores the file descriptor returned by the open function
     if(file_desc == -1){
          printf("\n Error opening file!");
          exit(1);
     }

     if(fstat(file_desc,&info) == -1){      // stat info stored in struct info
          printf("\nError in accessing fstat");
          exit(1);
     }

     strperm(info.st_mode,buf);
     printf("\nUser ID: %d\tGroup ID: %d",(int)info.st_uid,(int)info.st_gid);
     printf("\nMode : %d",info.st_mode);
     printf("\nInode no.:%ld",info.st_ino);
     printf("\nPermission:%s",buf );
     printf("\nDirectory:");
     if(S_ISDIR(info.st_mode))
          printf("True");
     else
          printf("False");
     printf("\nSize : %ld bytes",info.st_size);
     printf("\nHardlinks:%ld",info.st_nlink);
     printf("\nLast access:%s",ctime(&info.st_atime));
     printf("Last modified:%s",ctime(&info.st_mtime));
     printf("Last status change:%s",ctime(&info.st_ctime));

     close(file_desc);
     return 0;
}
