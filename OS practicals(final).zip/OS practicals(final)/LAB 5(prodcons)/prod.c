#include<stdio.h>
#include<fcntl.h>
#include<sys/types.h>
#include<unistd.h> //for ftruncate
#include<sys/stat.h>
#include<sys/mman.h>
#include<string.h>

int main(){
     const int SIZE = 4096; // 4096 bytes size for the shared memory
     const char * NAME = "PRODCON";
     const char * MESSAGE="ITEM 1";
     int shm_fd;
     void *ptr;
     shm_fd = shm_open(NAME,O_CREAT|O_RDWR,0666);
     ftruncate(shm_fd,SIZE);
     ptr = mmap(0,SIZE,PROT_WRITE,MAP_SHARED,shm_fd,0);
     sprintf(ptr,"%s",MESSAGE);
     return 0;
}
