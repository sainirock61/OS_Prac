// Preemptive priority scheduling

#include<stdio.h>

#define MAX_PROCESSES 30
struct Process{
    int pid;
    int waitingTime;
    int burstTime;
    int arrivalTime;
    int priority;
    int readyTime;
};

void printDetails(struct Process p[],int n){
    printf("\nID \tAT \tPR \tBT \tWT ");
    for(int i=0;i<n;i++){
        printf("\n%d \t%d \t%d \t%d \t%d", p[i].pid, p[i].arrivalTime, p[i].priority, p[i].burstTime, p[i].waitingTime);
    }
}
int main(){
    struct Process p[MAX_PROCESSES];
    int timer=0;
    int n,i;
    int remainingTime[MAX_PROCESSES];
    int totalTime=0;

    printf("\nEnter the number of processes(MAX:20):");
    scanf("%d",&n);
    printf("\nEnter the burst times:");
    for(i=0;i<n;i++){
        p[i].pid = i+1;
        int bt;
        scanf("%d",&bt);
        p[i].burstTime = bt;
        remainingTime[i] = bt;
        p[i].waitingTime = 0;
        p[i].readyTime = 0;
        totalTime+=bt;
    }
    printf("\nEnter the arrival times:");
    for(i=0;i<n;i++){
        int at;
        scanf("%d",&at);
        p[i].arrivalTime = at;
    }
    printf("\nEnter the priorities:");
    for(i=0;i<n;i++){
        int priority;
        scanf("%d",&p);
        p[i].priority = priority;
    }
    timer=0;
    while(timer<totalTime){

        //Find all ready processes
        for(i=0;i<n;i++){
            if(p[i].arrivalTime<=timer){
                p[i].readyTime=1;
            }
        }

        //Select the process with max(smallest in number) priority
        int min=0;
        int minP=p[min].priority;
        for(i=1;i<n;i++){
            if (remainingTime[i] > 0 && p[i].readyTime && p[i].priority < minP)
            {
                min = i;
                minP=p[i].priority;
            }
        }

        //Increment waitTime for other processes
        for(i=0;i<n;i++){
            if (remainingTime[i] > 0 && p[i].readyTime && i != min)
            {
                p[i].waitingTime++;
            }
        }
        printf("\nExecuting process %d",p[min].pid);
        remainingTime[min]--;
        timer++;   
    }
    printDetails(p,n);
    
}