#include<stdio.h>

#define MAX_PROCESSES 30
#define proc struct Process
struct Process{
    int pid;
    int burstTime;
    int waitingTime;
    int arrivalTime;
    int readyTime;
};
void printDetails(struct Process p_Arr[],int n){
    printf("\nID \tAT \tBT \tWT ");
    for(int i=0;i<n;i++){
        printf("\n%d \t%d \t%d \t%d", p_Arr[i].pid,p_Arr[i].arrivalTime,p_Arr[i].burstTime,p_Arr[i].waitingTime);
    }
}
int main(){
    int timer=0;
    int n,i;
    proc p[MAX_PROCESSES];
    int remainingTime[MAX_PROCESSES];
    int totalTime=0;

    printf("\nEnter the number of processes(MAX:20):");
    scanf("%d",&n);
    printf("\nEnter the burst times:");
    for(i=0;i<n;i++){
        p[i].pid = i+1;
        int bt;
        scanf("%d",&bt);
        p[i].burstTime = bt;
        remainingTime[i] = bt;
        p[i].waitingTime=0;
        p[i].readyTime = 0;
        totalTime+=bt;
    }
    printf("\nEnter the arrival times:");
    for(i=0;i<n;i++){
        int at;
        scanf("%d",&at);
        p[i].arrivalTime = at;
    }

    while(timer<totalTime){
        // Find all ready processes
        for(i = 0 ;i<n;i++){
            if(p[i].arrivalTime <= timer){
                p[i].readyTime = 1;
            }
        }

        //Select the shortest remaining time
        int min=0;
        int min_rt=remainingTime[min];
        for(i=1;i<n;i++){
            if(p[i].readyTime){
                if (remainingTime[i] > 0 && remainingTime[i] < min_rt)
                {
                    min = i;
                    min_rt = remainingTime[i];
                }
                
            }
        }
        
        //Increment the waiting time for all ready processes which are not running
        for(i=0;i<n;i++){
            if(remainingTime[i]>0 && p[i].readyTime && i!=min ){
                p[i].waitingTime++;
            }
        }

        printf("\nExecuting processes %d",p[min].pid);
        remainingTime[min]--;
        timer++;
    }
    printDetails(p,n);
    printf("\n");

}