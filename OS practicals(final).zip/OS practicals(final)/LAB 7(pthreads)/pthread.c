#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
int sum = 0;
void *summation(void * param){
     int i,upper = atoi(param);
     sum = 0;
     for(int i=0;i<=upper;i++){
          sum+=i;
     }
     pthread_exit(0);
}

int main(int argc,char * argv[]){
     pthread_t tid ;
     pthread_attr_t attr;
     if(argc<2){
          fprintf(stderr,"\nInsufficient command line arguments.");
          return(-1);
     }

     if(atoi(argv[1])<0){
          fprintf(stderr,"\n%d is less than 0",atoi(argv[1]));
          return -1;
     }
     //get the default thread attributes
     pthread_attr_init(&attr);

     //create the pthread
     pthread_create(&tid,&attr,summation,argv[1]);

     //the main thread waits for the thread to terminate
     pthread_join(tid,NULL);
     
     printf("\nSum = %d",sum);

}
