#include<stdio.h>
#include<stdlib.h>

void getLine(FILE *fptr,char* str,char delim){
	char c;
	int i=0;
	do{
		c=fgetc(fptr);
		if(c==delim || c==EOF)
			break;
		str[i++]=(char)c;

	}while(1);
	str[i]='\0';
}

int main(){
     FILE * fptr;
     int op;
     printf("\n1->Print Kernel version");
     printf("\n2->CPU type and model");
     printf("\n3->Memory information");
     printf("\nEnter your option:");
     scanf("%d",&op);
     switch(op){
          case 1:
               fptr = fopen("/proc/version","r");
               char kernel[100];
               if(fptr == NULL){
                    printf("\nError opening file");
                    exit(1);
               }
               getLine(fptr,kernel,'(');
               printf("%s\n",kernel);
               fclose(fptr);
               break;
          case 2:
               fptr = fopen("/proc/cpuinfo","r");
               if(fptr == NULL){
                    printf("\nError opening file");
                    exit(1);
               }
               int i=0;
               char model[100],cputype[100];
               while((i++)!=3){
                    getLine(fptr,model,'\n');
               }
               getLine(fptr,model,':');
               getLine(fptr,model,'\n');
               getLine(fptr,cputype,':');
               getLine(fptr,cputype,'\n');
               printf("\nCPU type : %s",cputype);
               printf("\nModel : %s\n",model);
               fclose(fptr);
               break;
          case 3:
               fptr = fopen("/proc/meminfo","r");
               char total[20],used[20],free[20];
               if(fptr == NULL){
                    printf("\nError opening file");
                    exit(1);
               }
               getLine(fptr,total,':');
               getLine(fptr,total,'\n');
               getLine(fptr,free,':');
               getLine(fptr,free,'\n');
               getLine(fptr,used,':');
               getLine(fptr,used,'\n');
               printf("\nTotal memory: %s",total);
               printf("\nUsed memory: %s",used);
               printf("\nFree memory: %s\n",free);
               fclose(fptr);
               break;
          default:
               printf("Invalid option\n");
     }

}
